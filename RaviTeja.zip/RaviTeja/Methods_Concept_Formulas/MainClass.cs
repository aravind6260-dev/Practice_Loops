﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods_Concept_Formulas
{
    internal class MainClass
    {
        static void Main(string[] args)
        {
            Formulas formulas = new Formulas();
            double output = formulas.DistanceBetweenTwoPoints(12, 25, 22, 31);
            Console.WriteLine(output);
            formulas.SlopeOfLine(output, 29, output, 56);
            Calling calling = new Calling();
            calling.CallMethod();            
        }
    }
    public class Formulas
    {
        public double DistanceBetweenTwoPoints(double x1, double x2, double y1, double y2)
        { 
            double distance = Math.Sqrt(Math.Pow(x2- x1, 2) + Math.Pow(y2 - y1, 2) );
            return distance;           
        }
        public double Cuboid(double length, double width, double height)
        {
            double cuboid = 2*((length * width) + (width * height) + (length * height));
            return cuboid;
        }
        public  void SlopeOfLine(double x1, double x2, double y1, double y2)
        {
            double slope = (y2 - y1) / (x2 - x1);
            Console.WriteLine(slope);
        }
        
    }
    public class Calling
    {
        public void CallMethod()
        {
            Formulas formulas = new Formulas();
            double output = formulas.Cuboid(10.5, 12.3, 15);
            Console.WriteLine(output);
        }
    }
}
