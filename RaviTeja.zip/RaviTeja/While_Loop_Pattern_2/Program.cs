﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_Loop_Pattern_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while(i <= 8)
            {
                int j = 1;
                while(j <= i)
                {
                    Console.Write("*");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}
