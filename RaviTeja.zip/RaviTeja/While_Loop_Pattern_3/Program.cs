﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_Loop_Pattern_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while(i <= 8)
            {
                int k = 8;
                while (k >= i)
                {
                    Console.Write(" ");

                    k--;
                }
                int j = 1;
                while(j <= 2*i-1)
                {
                    
                    Console.Write("*");
                    j++;
                }
                
                Console.WriteLine();
                i++;
            }
        }
    }
}
