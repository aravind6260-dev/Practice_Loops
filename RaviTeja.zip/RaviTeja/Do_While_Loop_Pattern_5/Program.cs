﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_While_Loop_Pattern_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 8;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(" ");
                    j++;
                } while (j <= i);
                int k = 8;
                do
                {
                    Console.Write("*");
                    k--;
                } while (k >= i);
                Console.WriteLine();
                i--;
            } while (i >= 1);
        }
    }
}
