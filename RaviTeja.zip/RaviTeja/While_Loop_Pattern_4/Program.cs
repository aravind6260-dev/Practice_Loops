﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_Loop_Pattern_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 8)
            {
                int j = i;
                while (j <= 7)
                {
                    Console.Write(" ");
                    j++;
                }
                int k = 1;
                while (k <= 2 * i - 1)
                {
                    Console.Write("*");
                    k++;
                }
                Console.WriteLine();
                i++;
            }
            int l = 1;
            while (l <= 8)
            {
                int m = l;
                while (m >= 1)
                {
                    Console.Write(" ");
                    m--;
                }
                int n = 13;
                while (n >= 2*l-1)
                {
                    Console.Write("*");
                    n--;
                }
                Console.WriteLine();
                l++;
            }
        }
    }
}
