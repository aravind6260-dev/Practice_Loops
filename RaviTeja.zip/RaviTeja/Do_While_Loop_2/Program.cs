﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_While_Loop_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                int j = 1;
                do
                {
                    Console.Write(i+" ");
                    j++;
                } while (j <= i);
                Console.WriteLine();
                i++;
            }while (i <= 5);
        }
    }
}
