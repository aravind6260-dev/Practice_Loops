﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_Loop_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 5;
            while(i >= 1)
            {
                int j = 5;
                while(j >= i)
                {
                    Console.Write(i + " ");
                    j--;
                }
                Console.WriteLine();
                i--;
            }
        }
    }
}
