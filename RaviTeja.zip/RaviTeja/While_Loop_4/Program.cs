﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_Loop_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 5;
            while(i >= 1)
            {
                int j = 1;
                while(j <= i)
                {
                    Console.Write(j+" ");
                    j++;
                }
                Console.WriteLine();
                i--;
            }

        }
    }
}
