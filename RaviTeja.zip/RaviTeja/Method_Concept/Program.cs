﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Method_Concept
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Geometry geometry = new Geometry();
            geometry.Addition(5, 8);
            int output = geometry.Substraction(15, 7);            
            geometry.Multiplication(output, 5);
            Operation operation = new Operation();
            operation.CallMethod();
        }
    }
    public class Geometry
    {
        public void Addition(int value1, int value2)
        {
            int result = value1 + value2;
            Console.WriteLine(result);
        }
        public int Substraction(int value1, int value2)
        {
            int result = value1 - value2;
            return result;            
        }
        public void Multiplication(int value1, int value2)
        {
            int result = value1 * value2;
            Console.WriteLine(result);
        }
    }
    public class Operation
    {
        public void CallMethod()
        {
            Geometry geometry = new Geometry();
            geometry.Addition(13, 25);
            geometry.Substraction(25, 13);
        }

    }
        
}
