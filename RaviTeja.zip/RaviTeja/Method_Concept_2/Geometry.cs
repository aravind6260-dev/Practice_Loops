﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Method_Concept_2
{
    internal class Geometry
    {
        public void Addition(int value1, int value2)
        {
            int result = value1 + value2;
            Console.WriteLine(result);
        }
        public int Substraction(int value1, int value2)
        {
            int result = value1 - value2;
            return result;


        }
        public void Multiplication(int value1, int value2)
        {
            int result = value1 * value2;
            Console.WriteLine(result);
        }
    }
}
