﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Method_Concept_2
{
    internal class Operation
    {
        public void CallMethod()
        {
            Geometry geometry = new Geometry();
            geometry.Addition(13, 25);
            geometry.Substraction(25, 13);
            geometry.Multiplication(5, 5);
        }
    }
}
