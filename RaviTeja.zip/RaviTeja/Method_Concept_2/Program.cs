﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Method_Concept_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Geometry geometry = new Geometry();
            geometry.Addition(5, 8);
            int output = geometry.Substraction(15, 7);
            geometry.Multiplication(output, 5);

            Operation operation = new Operation();
            operation.CallMethod();

        }
    }
    
}
