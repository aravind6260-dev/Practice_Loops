﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_10
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //string name = "Aravind";
            //for (int i = name.Length-1; i >=0; i--)
            //{
            //    Console.Write(name[i]);
            //}

            for (int m = 1; m <= 6; m++)
            {
                Console.Write(" ");
            }
            Console.Write("*");
            Console.WriteLine();

            for (int n = 1; n <= 6; n++)
            {
                for (int i = n; i <= 5; i++)
                {
                    Console.Write(" ");
                }
                for (int p = 1; p <= 1; p++)
                {
                    Console.Write("*");
                }
                for (int q = 1; q <= 2 * n - 1; q++)
                {
                    Console.Write(" ");
                }
                for (int r = 1; r <= 1; r++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();

            }
            for (int s = 1; s <= 13; s++)
            {
                Console.Write("*");
            }
        }
    }
}
