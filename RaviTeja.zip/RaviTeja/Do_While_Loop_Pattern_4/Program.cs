﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Do_While_Loop_Pattern_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                int j = 8;
                do
                {
                    Console.Write(" ");
                    j--;
                } while (j >= i);
                int k = 1;
                do
                {
                    Console.Write("*");
                    k++;
                } while (k <= 2 * i - 1);
                Console.WriteLine();
                i++;
            } while (i <= 8);
            int l = 7;
            do
            {
                int m = 8;
                do
                {
                    Console.Write(" ");
                    m--;
                } while (m >= l);
                int n = 1;
                do
                {
                    Console.Write("*");
                    n++;
                } while (n <= 2 * l - 1);
                Console.WriteLine();
                l--;
            } while (l >= 1);
        }
    }
}
