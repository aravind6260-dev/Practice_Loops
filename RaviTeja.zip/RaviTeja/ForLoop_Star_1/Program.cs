﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 8; i++)
            {
                for (int j = i; j <= 8; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
            //for (int i = 1; i <= 8; i++)
            //{
            //    for (int j = 8; j <= 8 - i; j++)
            //    {
            //        Console.Write(" ");
            //    }
            //    for (int k = 1; k <= 8 - i; k++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine();
            //}
        }
    }
}
