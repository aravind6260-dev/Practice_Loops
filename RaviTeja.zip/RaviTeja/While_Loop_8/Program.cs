﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_Loop_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                int j = i;
                while (j <= 5)
                {
                    Console.Write(i + " ");
                    j++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}
