﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for(int m  = 1; m <= 7; m++)
            {
                Console.Write("*");
                
            }
            Console.WriteLine();
            for (int i = 1; i <= 5; i++)
            {
                for (int j = i; j <= i; j++)
                {
                    Console.Write("*     *");
                   
                }
               
                Console.WriteLine();
            }
            for(int k = 1; k <= 7; k++)
            {
                Console.Write("*");
            }

        }
    }
}
