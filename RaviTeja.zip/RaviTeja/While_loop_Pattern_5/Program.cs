﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace While_loop_Pattern_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while(i <= 8)
            {
                int j = 8;
                while(j >= i)
                {
                    Console.Write(" ");
                    j--;
                }
                int k = 1;
                while(k <= i)
                {
                    Console.Write("*");
                    k++;
                }
                Console.WriteLine();
                i++;
            }
        }
    }
}
