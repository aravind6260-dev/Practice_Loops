﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 8; i >= 1; i--)
            {
                for (int j = i; j <= 8; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
