﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 10; j >= i; j--)
                {
                    Console.Write(" ");

                }
                for (int k = 1; k <= i; k++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();

            }
           
            for (int i = 1; i <= 10; i++)
            {
                for (int m = 0; m <= i; m++)
                {
                    Console.Write(" ");
                }
                for (int n = 1; n <= 10-i; n++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
