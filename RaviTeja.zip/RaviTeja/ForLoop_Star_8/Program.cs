﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.Write(" ");
            //for (int m = 1; m < 16; m++)
            //{
            //    Console.Write("*");
            //}

            //Console.WriteLine();
            //for (int i = 1; i <= 7; i++)
            //{

            //    for (int j = i; j <= i; j++)
            //    {
            //        Console.Write(" ");
            //    }
            //    for (int k = i; k <= 7; k++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine();

            //}
            //Console.Write("");
            //int p = 7;
            //for (int m = 1; m <= p; m++)
            //{

            //    for (int n = 1; n <= m; n++)
            //    {
            //        Console.Write(" ");
            //    }
            //    for (int l = 1; l <= p - m; l++)
            //    {
            //        Console.Write("*");
            //    }
            //    Console.WriteLine();
            //}

            //Reference:
            //int rows = 10;  
            //int stars = 20; 

            //for (int i = 0; i < stars; i++)
            //{
            //    Console.Write("*");
            //}
            //Console.WriteLine();

            //int left = 0;
            //int right = stars - 1;

            //for (int i = 0; i < rows; i++)
            //{
            //    for (int j = right; j < stars; j++)

            //        Console.Write("*");


            //    for (int j = left; j < right; j++)
            //        Console.Write(" ");

            //    for (int j = 0; j < left; j++)
            //        Console.Write("*");


            //    left++;
            //    right--;
            //    Console.WriteLine();
            //}

            for (int m = 1; m < 16; m++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
            for (int n = 1; n <= 10; n++)
            {
                for(int p = n; p <= 7; p++) 
                { 
                    Console.Write("*"); 
                }
                for(int q = 1; q <= 2*n-1; q++)
                {
                    Console.Write(" ");
                }
                for (int r = n; r <= 7; r++)
                {
                    Console.Write("*");
                }
               
                Console.WriteLine();
            }

        }
    }
}
