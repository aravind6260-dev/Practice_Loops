﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i<=8; i++)
            {
               for(int j = 1; j <= 8-i; j++)
                {
                    Console.Write(" ");
                }
               for(int k = 1; k<=2*i-1; k++)
                {
                    Console.Write("*");
                }
                          
               Console.WriteLine();
            }
            
            for(int l  = 7; l>=1; l--)
            {
                for (int m = 1; m <= 8 - l; m++)
                {
                    Console.Write(" ");
                }
                for (int n = 1; n<=2*l-1; n++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
