﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoop_Star_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            for (int m = 1; m <= 1; m++)
            {
                Console.Write("*");
            }
            Console.WriteLine();

            for (int n = 1; n <= 8; n++)
            {
                for (int p = 1; p <= 1; p++)
                {
                    Console.Write("*");
                }
                for (int q = 1; q <= n - 1; q++)
                {
                    Console.Write(" ");
                }
                for (int r = 1; r <= 1; r++)
                {
                    Console.Write("*");
                }

                Console.WriteLine();
                
            }
            for (int s = 1; s <= 10; s++)
            {
                Console.Write("*");
            }
        }
    }
}
